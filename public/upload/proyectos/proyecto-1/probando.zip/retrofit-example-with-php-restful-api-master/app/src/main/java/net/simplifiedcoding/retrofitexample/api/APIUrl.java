package net.simplifiedcoding.retrofitexample.api;

/**
 * Created by Belal on 14/04/17.
 */

public class APIUrl {
    public static final String BASE_URL = "http://192.168.1.102/RetrofitExample/public/";
}
