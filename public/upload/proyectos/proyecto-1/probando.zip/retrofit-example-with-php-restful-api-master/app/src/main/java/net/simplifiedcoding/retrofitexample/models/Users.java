package net.simplifiedcoding.retrofitexample.models;

import java.util.ArrayList;

/**
 * Created by Belal on 14/04/17.
 */

public class Users {

    private ArrayList<User> users;

    public Users() {

    }

    public ArrayList<User> getUsers() {
        return users;
    }

    public void setUsers(ArrayList<User> users) {
        this.users = users;
    }
}
